GUJRAT</h2>
                    <a class="btn btn-primary js-scroll-trigger" href="{{route('booking')}}">Buy Ticket</a>
                </div>
            </div>
        </header>
        <!-- About-->
        <section class="about-section text-center" id="about">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <h2 class="text-white mb-4">Contact Us</h2>
                        <p class="text-white-50">
                        RAJKOT<br>
  Address : Madhapar chokdi,near petrol pump<br>

  <!--Phone : 09606444777,01711612433 (Call Center)-->

  Mobile :9725145109
                             
                            
                        </p>
                        <p class="text-white-50">
                        JAMNAGAR<br>
  Address : Gurudwara chokdi,near by Croma<br>

  <!--Phone : 09606444777,01711612433 (Call Center)-->

  Mobile :9725145109


                            
                            
                        </p>
                        </p>
                        <p class="text-white-50">
                        AHMEDABAD<br>
  Address : geeta mundir bus stop<br>

 <!-- Phone : 09606444777,01711612433 (Call Center)-->

  Mobile :9725145109


                            
                            
                        </p>
                        <p class="text-white-50">
                        Abdullahpur (Uttara)<br>
  Address : 7/D,H#20, Sec# 9 ,Uttara<br>

  Phone : 028956345<br>

  Mobile : 01711624390
 


  <!--<div> <a href="">the preview page</a></div>-->