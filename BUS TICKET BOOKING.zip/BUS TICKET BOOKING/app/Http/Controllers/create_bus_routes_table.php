<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class create_bus_routes_table extends Controller
{
    //
}
